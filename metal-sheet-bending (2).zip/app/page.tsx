"use client"

import MetalSheetBendingTool from "@/components/metal-sheet-bending-tool"

export default function Home() {
  return (
    <main className="container mx-auto py-8">
      <MetalSheetBendingTool />
    </main>
  )
}

